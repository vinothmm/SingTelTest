package com.singtel.test.SingtelTest;

public interface SwimmingAnimal extends Animal {

    String swim();

}
