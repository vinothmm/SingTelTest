package com.singtel.test.SingtelTest;


public class Dolphin implements SwimmingAnimal {
    public String swim() {
        return "I am swimming";
    }
}
