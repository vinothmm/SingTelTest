package com.singtel.test.SingtelTest;

import java.util.Locale;

public enum Language {
    FRENCH("fr","FR"),
    ENGLISH("en","US"),
	DANISH("dn","DN");
	
	private String langCode;
	private String countryCode;
	
	Language(String langCode, String countryCode) {
		this.langCode = langCode;
		this.countryCode = countryCode;
	}
	
	public Locale getLocale() {
		return new Locale(langCode, countryCode);
	}
}
