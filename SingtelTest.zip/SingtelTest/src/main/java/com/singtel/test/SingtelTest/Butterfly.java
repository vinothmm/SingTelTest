package com.singtel.test.SingtelTest;


public class Butterfly implements FlyingAnimal {
    public String fly() {
        return "I am flying";
    }
}

