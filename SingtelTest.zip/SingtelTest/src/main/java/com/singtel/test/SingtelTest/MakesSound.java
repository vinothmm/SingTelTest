package com.singtel.test.SingtelTest;

public interface MakesSound {
    String makeSound();
}

