package com.singtel.test.SingtelTest;

public class Fish implements SwimmingAnimal {
    public String swim() {
        return "I am swimming";
    }
}
