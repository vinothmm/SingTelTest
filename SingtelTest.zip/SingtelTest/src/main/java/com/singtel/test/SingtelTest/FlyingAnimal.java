package com.singtel.test.SingtelTest;


public interface FlyingAnimal extends Animal {

    String fly();

}