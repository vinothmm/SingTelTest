package com.singtel.test.SingtelTest;

public interface WalkingAnimal extends Animal {
    String walk();
}

