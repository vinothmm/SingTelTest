package com.singtel.test.SingtelTest;

public interface Animal {
}

