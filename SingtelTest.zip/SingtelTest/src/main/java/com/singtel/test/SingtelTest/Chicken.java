package com.singtel.test.SingtelTest;

public class Chicken extends Bird {
    @Override
    public String makeSound() {
        return "Cluck, cluck";
    }

}

