package com.singtel.test.SingtelTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test; 
public class SoundTranslatorTest {

    @Test
    public void testRoosterSoundTranslationToUrudu() {
        Rooster rooster = new Rooster();
        assertEquals("cocorico", rooster.makeSound(Language.FRENCH));
    }
}
